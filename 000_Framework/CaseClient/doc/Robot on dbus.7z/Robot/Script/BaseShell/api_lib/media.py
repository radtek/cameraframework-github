"""
Used for Media API control
"""
import re
import json
from dbus_library import DbusLibrary
from logger import Logger
from BaseShell import connections

LOG_OBJ = Logger('Media')


def invoke_media_service(method_name, params={}, timeout=0):
    """Invoke MediaService API through "dbus-send" and "dbus-monitor" with parameters

    | Input Parameters | Man. | Description |
    |   method_name    | Yes  | media service api name, such as "getDevice", "playMediaObject" |
    |     params       |  No  | input parameters for api, default is "{}" |
    |     timeout      |  No  | default is 0 and will send synchronous dbus command to Media service,
                                otherwise send asynchronous dbus command |

    | Return value | API result or Signal infromation |

    Example
    | Call Media Service | getDevices |
    | Call Media Service | requestPlaybackAction | {"action":0, "param":1} |
    | Call Media Service | playItemFromList | {"list_hdl":1320992, "start_index":1} | 4 |
    """
    (ip_address, port) = connections.get_device_attributes()
    DBUS_OBJ = DbusLibrary(str(ip_address))

    try:
        if timeout ==0:
            LOG_OBJ.info("Try to send synchronous dbus command.")
            ret = DBUS_OBJ.send_sync_dbus_command('Media', method_name, params)
        else:
            LOG_OBJ.info("Try to send asynchronous dbus command.")
            if not isinstance(timeout, int):
                timeout = int(timeout)
            ret = DBUS_OBJ.send_async_dbus_command('Media', method_name, params, timeout)

        return ret
    except Exception, e:
        print e
        LOG_OBJ.error("Call Media API:\"%s\" with Input:\"%s\" failed" % (method_name, params))



def check_device(dbus_msg, key):
    """Check device by specificed key from given message and return it's ID

    | Input Parameters | Man. | Description |
    |     dbus_msg     | Yes  | Dbus command response after "getDevices" |
    |       key        | Yes  | value to distinguish device |

    Example
    | Check Device | ${response} | INTERNET |
    """
    LOG_OBJ.info('Try to get device ID from "%s" based on "%s"' % (dbus_msg.contents, key))
    try:
        for msg in dbus_msg.contents:
            if 'devices' in msg.keys():
                devices_msg = msg['devices']
                device_id = 0
                for device in devices_msg:
                    if key in device.values():
                        if 'id' in device.keys():
                            device_id = device['id']
                        elif 'tag' in device.keys():
                            device_id = device['tag']

                if device_id == 0:
                    LOG_OBJ.error('Device not exixted')
                else:
                    LOG_OBJ.info('Device ID matched is: %s' % str(device_id))
                    return device_id
            else:
                LOG_OBJ.warn('There is no devices information in the given message')
    except Exception, e:
        print e
        LOG_OBJ.error('Can not get device id for "%s"' %(key))



if __name__ == '__main__':
    res = invoke_media_service('getDevices')
    device_id = get_device_id(res, 'DEMI')
    print device_id
    res = invoke_media_service('activeDevice', {"id":device_id})
    #res = invoke_media_service('activeDevice', {"id":3992977410})
    check_service_result(res)
  #  invoke_media_service('requestPlaybackAction', {"action":0, "param":1})
    pass

