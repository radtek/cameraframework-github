
import os
import sys
import json
import subprocess


class DbusMessage():
    """ Stores the data for one DBUS message
    """
    method_type = None
    sender = None
    dest = None
    path = None
    interface = None
    contents = None
    reply_serial = None

    def __init__(self):
        """ Returns an empty DBUS message
        """
        pass


    @staticmethod
    def BufferData(buffer):
        """ Generates a DBUS message instance from a buffer (as given by
            dbus-monitor)

            The buffer is a list of lines, with buffer[0] being the header,
            followed by the data.
        """
        # Validate the buffer
        buffer = DbusMessage.ValidateBuffer(buffer)

        # Parse the buffer into a message instance
        datalist = buffer[0].split(' ')
        dbusmsg = DbusMessage()

        # Populate data fields
        for param in datalist:
            if 'sender' in param:
                dbusmsg.sender = param.split('=')[1]
            if 'dest' in param and \
               'null' not in param and \
               'destination' not in param:
                dbusmsg.dest = param.split('=')[1]
            if 'path' in param:
                dbusmsg.path = param.split('=')[1].replace(';', '')
            if 'interface' in param:
                dbusmsg.interface = param.split('=')[1].replace(';', '')
            if 'member' in param:
                dbusmsg.member = param.split('=')[1]

        # Finally, get the type
        if datalist[0] == 'signal':
            dbusmsg.type = 'signal'
        else:
            dbusmsg.type = 'method_%s' % datalist[1]

        return (dbusmsg, buffer)


    @staticmethod
    def FromParams(method_type, sender, dest, path, interface, contents, reply_serial=None):
        """ Generates a DBUS message instance from parameters
        """
        dbusmsg = DbusMessage()
        dbusmsg.method_type = method_type
        dbusmsg.sender = sender
        dbusmsg.dest = dest
        dbusmsg.path = path
        dbusmsg.interface = interface

        # Contents need to be put into the required format "string:"data""
        dbusmsg.contents = []
        for item in contents:
            dbusmsg.contents.append(item)

        # Optionally, set a reply_serial value
        dbusmsg.reply_serial = reply_serial
        return dbusmsg


    @staticmethod
    def FromBuffer(buffer):
        (dbusmsg, buffer_) = DbusMessage.BufferData(buffer)

        dbusmsg.contents = []
        for contentitem in buffer_[1:]:
            removestring = contentitem.replace('string ', '')
            removestring = removestring.strip()

            if not (removestring.startswith('"') and removestring.endswith('"')):
                raise Exception, 'DBUS_DATATYPES ERROR: Error validating \
contents; expected double-quote bound string, got <%s>' % (removestring)

            dbusmsg.contents.append(json.loads(removestring[1:-1]))

        return dbusmsg


    @staticmethod
    def FromBufferMonitor(buffer):
        (dbusmsg, buffer_) = DbusMessage.BufferData(buffer)

        dbusmsg.contents = []
        for contentitem in buffer[1:]:
            removestring = contentitem.replace('string ', '')
            removestring = removestring.strip()

            if not (removestring.startswith('"') and removestring.endswith('"')):
                raise Exception, 'DBUS_DATATYPES ERROR: Error validating \
contents; expected double-quote bound string, got <%s>' % (removestring)

            removestring = removestring[1:-1]
            dbusmsg.contents.append(removestring)

        return dbusmsg


    @staticmethod
    def ValidateBuffer(buffer):
        """ Accepts a buffer, and raises if an error was found.
            Returns a 'trimmed' buffer containing valid messages
        """
        # Check for errors
        knownerrors = ('is badly formed',
                       'Failed to open connection to',
                       'Did not receive a reply',
                       'Error com.harman.service.Error:',
                       'Error org.freedesktop.DBus.Error.ServiceUnknown')

        # If any of the known errors are found, raise giving the errors
        for error in knownerrors:
            for item in buffer:
                if error in item:
                    raise Exception, 'DBUS_DATATYPES ERROR: Error \
                validating buffer: error %s in item %s' % (error, item)

        # Validate header
        validformats = ('sender' not in buffer[0], 'dest' not in buffer[0])

        if any(validformats):
            raise Exception, 'DBUS_DATATYPES ERROR: Malformed DBus header! \
Data - %s, validformats -(sender, dest) - %s' % (buffer[0], validformats.__str__())

        # Trim the buffer and return it
        parsedbuffer = []
        for item in buffer:
            if any(('string' in item, 'method' in item, 'signal' in item)):
                parsedbuffer.append(item.strip())

        return parsedbuffer


    @staticmethod
    def ProcessIncomingData(data):
        """ Processes a one-line bit of data from dbus-monitor.

            Strips unnecessary information and prepares it for a message
            object. Fixes the " occurring at the end of some blocks of
            messages.
        """
        data = data.rstrip()

        # If the data, after removing whitespace, is a single " it is
        # useless so return nothing
        if data == '"' or data == '':
            return ''

        # Check for errors
        knownerrors = ['Failed to open connection']

        for error in knownerrors:
            if error in data:
                raise Exception, 'DBUS_DATATYPES ERROR: Dbus Error: %s' % data

        # Parse the data for empty lines and the bat file lines at the
        # beginning
        if 'DBUS_SESSION_BUS' in data:
            return ''
        if 'dbus-monitor' in data:
            return ''
        if 'Family' in data:
            return ''

        # Sometimes it is missing a " at the end (there was a \r or \n at the
        # end before " so it was clipepd and discarded0
        numquotes = 0
        for char in data:
            if char == '"':
                numquotes += 1

        # If the number of quotes do not match, append one
        if numquotes % 2 != 0:
            data += '"'

        return data

