"""
Used for BlueTooth API control
"""
import re
import json
from dbus_library import DbusLibrary
from logger import Logger
from BaseShell import connections

LOG_OBJ = Logger('BlueTooth')

def invoke_bluetooth_service(method_name, params={}, timeout=0):
    """Invoke BlueToothService API through "dbus-send" and "dbus-monitor" with parameters

    | Input Parameters | Man. | Description |
    |   method_name    | Yes  | bluetooth service api name, such as "setBluetoothStatus" |
    |     params       |  No  | input parameters for api, default is "{}" |
    |     timeout      |  No  | default is 0 and will send synchronous dbus command to BT service,
                                otherwise send asynchronous dbus command |

    | Return value | API result |

    Example
    | Call Bluetooth Service | setBluetoothStatus | {"enable":"True"} |
    | Call Bluetooth Service | setBluetoothStatus | {"enable":"True"} | 5 |
    """
    (ip_address, port) = connections.get_device_attributes()
    DBUS_OBJ = DbusLibrary(str(ip_address))

    try:
        if timeout ==0:
            LOG_OBJ.info("Try to send synchronous dbus command.")
            ret = DBUS_OBJ.send_sync_dbus_command('BluetoothService', method_name, params)
        else:
            LOG_OBJ.info("Try to send asynchronous dbus command.")
            if not isinstance(timeout, int):
                timeout = int(timeout)
            ret = DBUS_OBJ.send_async_dbus_command('BluetoothService', method_name, params, timeout)

        return ret
    except Exception, e:
        print e
        LOG_OBJ.error("Call BluetoothService API:\"%s\" with Input:\"%s\" failed" % (method_name, params))


if __name__ == '__main__':
#    invoke_service()
    pass

