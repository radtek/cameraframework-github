import os
import sys
import time
import json
import subprocess
from logger import Logger

from dbus_libs.dbus_datatypes import DbusMessage
from dbus_libs.dbus_monitor import DbusMonitor
from dbus_libs.dbus_json_snapshot import DbusJsonSnapshot

LOG_OBJ = Logger('DbusLibrary')

class DbusLibrary():
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    # Component attributes
    dbussender = None
    dbusmonitor = None
    jsonsnapshot = None
    waiting_on_signals = None

    def __init__(self, ip='10.80.104.159', port='6667'):
        self.ip = ip
        self.port = port
        LOG_OBJ.info("Device IP address is: %s" % (self.ip))


    def __cleanup(self):
        """ Stops dbus-monitor if it is running, which should be the only
            resource that needs to be terminated.
        """
        self.dbusmonitor.Stop()


    def send_sync_dbus_command(self, service, method, params):
        """ Send synchronous dbus command
        """
        message = self.__build_json_rpc_dbus_message(service, method, params)
        command = self.__build_send_command(message)
        command_line = " ".join(command)
        LOG_OBJ.info("Will execute dbus command: %s" % (command_line))

        # Send the command by TCP
        dbusenv = os.environ.copy()
        sessionvar = 'tcp:host=%s,port=%s' % (self.ip, self.port)
        dbusenv['DBUS_SESSION_BUS_ADDRESS'] = sessionvar
        try:
            sendproc = subprocess.Popen(command_line, stdout=subprocess.PIPE, \
stderr=subprocess.STDOUT, env=dbusenv)
        except Exception, e:
            print e
            LOG_OBJ.error("Failed to send Dbus command through subprocess method")

        # Get the data from the command and process it into a buffer
        data = sendproc.communicate()[0]
        databuffer = []
        for line in data.split('\r'):
            databuffer.append(line.strip())

        # Process the databuffer
        newbuffer = []
        for line in databuffer:
            processedline = DbusMessage.ProcessIncomingData(line)
            if processedline != '':
                newbuffer.append(processedline)
        LOG_OBJ.info('Dbus command response: %s' % (newbuffer))

        # Return a new message with results
        ret = DbusMessage.FromBuffer(newbuffer)

        return ret


    def send_async_dbus_command(self, service, method, params, timeout=4):
        """ Send asynchronous dbus command
        """
        try: # Start Dbus-Monitor
            # Get an instance of the JSON snapshot
            self.jsonsnapshot = DbusJsonSnapshot()
            # Get instances for the remote dbus send/receive and
            # register a callback
            self.dbusmonitor = DbusMonitor(self.ip, self.port)
            self.dbusmonitor.RegisterCallback(self.__dbus_message_callback)
            self.dbusmonitor.Start()

            message = self.__build_json_rpc_dbus_message(service, method, params)
            command = self.__build_send_command(message)
            command_line = " ".join(command)
            LOG_OBJ.info("Will execute dbus command: %s" % (command_line))

            # Send the command by TCP
            dbusenv = os.environ.copy()
            sessionvar = 'tcp:host=%s,port=%s' % (self.ip, self.port)
            dbusenv['DBUS_SESSION_BUS_ADDRESS'] = sessionvar
            try:
                sendproc = subprocess.Popen(command_line, stdout=subprocess.PIPE, \
stderr=subprocess.STDOUT, env=dbusenv)
            except Exception, e:
                print e
                LOG_OBJ.error("Failed to send Dbus command through subprocess method")

            # Wait for timeout seconds to get the signals list.
            for i in range(0, int(timeout) * 2):
                time.sleep(.5)

            ret = self.jsonsnapshot.signal_list

            return ret
        finally:
            self.__cleanup()


    def __build_send_command(self, message, timeout=None):
        """ Builds the command to send to the commandline for dbus-send process
        """
        encoding = sys.getfilesystemencoding()
        command = ['dbus-send']
        command.append('--print-reply')
        if timeout:
            command.append('--reply-timeout=%s' % timeout)
        command.append('--session')
        if message.method_type:
            command.append('--type=%s' % message.method_type)
        if message.dest:
            command.append('--dest="%s"' % message.dest)
        if message.path:
            command.append(message.path)
        if message.interface:
            command.append(message.interface)

        # Add message data contents
        for item in message.contents:
            item = item.replace('"', r'\"')
            command.append('string:"%s"' % item)

        return command


    def __build_json_rpc_dbus_message(self, service, method, params):
        """ Internal method for getting a Dbus message representing a
            harman JSON remote procedure call.
        """
        method_type = 'method_call'
        sender = ''
        dest = 'com.harman.service.' + service
        path = '/com/harman/service/' + service
        interface = 'com.harman.ServiceIpc.Invoke'
        # Convert from unicode to string if it a unicode object.
        if isinstance(params, unicode):
            params = str(params)

        # Convert params if it is not already a string
        if not isinstance(params, str):
            params = json.dumps(params)

        # Apply message contents
        contents = [method, params]
        # Return with the new message instance
        return DbusMessage.FromParams(method_type, sender, dest,
                                      path, interface, contents)


    def __dbus_message_callback(self, event):
        self.jsonsnapshot.ReceiveDbusMessage(event['Message'])



if __name__ == '__main__':
    pass

