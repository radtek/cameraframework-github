
class Logger:
    def __init__(self, service, loglevel='Info'):
        """ "WARN", "INFO", "DEBUG", "TRACE"
        """
        self.service = service
        self._loglevel = loglevel

    def trace(self, msg):
        self._log(msg, "Trace")

    def debug(self, msg):
        self._log(msg, "Debug")

    def info(self, msg):
        self._log(msg, "Info")

    def error(self, msg):
        self._log(msg, "Error")
        raise Exception, msg

    def warn(self, msg):
        self._log(msg, "Warn")

    def is_trace(self):
        return self._loglevel.upper() == 'TRACE'

    def log(self, msg, loglevel = None):
        self._log(msg, loglevel)

    def _log(self, msg, loglevel=None):
        loglevel = loglevel == None and self._loglevel or loglevel
        msg = msg.strip()
        if msg != '' and loglevel is not None:
            print '%s %s, %s' % (self.service, loglevel.upper(), msg)
