"""
Used for Common Operation
"""
import os
import re
import json
import subprocess
from logger import Logger

LOG_OBJ = Logger('Common')


def get_property_value(message, key='id', specified=''):
    """Try to get value from given message with specificed key

    | Input Parameters | Man. | Description |
    |     message      | Yes  | Dbus synchronous command response after invoke service API |
    |       key        | Yes  | the name of property to get, default is 'id' |
    |    specified     | No   | the format should be "name:value",
                                such as "name:Colbie Caillat". And defaule is '' |

    Example
    | Get Property Value | ${response} | repeat |
    | Get Property Value | ${response} |   id   | name:Colbie Caillat |
    | Get Property Value | ${response} |  index | name:Colbie Caillat |
    """
    try:
        ret_value = ''
        if specified != '':
            LOG_OBJ.info('Try to get value of "%s" from "%s" based on [%s]' % (key, message.contents, specified))
            (name, value) = specified.split(':')
            for sub_dict in message.contents[0]['list_items']:
                if sub_dict[name] == value:
                    if key == 'index':
                        ret_value = message.contents[0]['list_items'].index(sub_dict)
                    else:
                        ret_value = sub_dict[str(key)]
                    LOG_OBJ.info('"%s" value is: "%s" base on [%s]' % (key, ret_value, specified))
                    return ret_value
        else:
            LOG_OBJ.info('Will try to get value of "%s" from "%s"' % (key, message.contents))
            if key in message.contents[0].keys():
                ret_value = message.contents[0][key]
                LOG_OBJ.info('"%s" value is: "%s"' % (key, ret_value))
                return ret_value
            else:
                LOG_OBJ.error('No key: "%s" information' % (key))

        if ret_value == '':
            LOG_OBJ.error('Can not get informaiton for: %s' % (key))
    except Exception, e:
        print e
        LOG_OBJ.error('Failed to get property value')


def get_signal_value(message, specified=''):
    """Try to get value from given message with specificed key

    | Input Parameters | Man. | Description |
    |     message      | Yes  | Dbus asynchronous command response after invoke service API |
    |    specified     | No   | Signal information specified |

    Example
    | Get Signal Value | ${response} | title |
    | Get Signal Value | ${response} | artist |
    """
    LOG_OBJ.info('Try to get sinal from "%s" specified by "%s"' % (message, specified))
    for item in message:
        data = item[-1]
        if re.search(specified, data):
            data = re.sub("{|}|\"|\'", "", data)
            if re.search(',', data):
                data_list = data.split(',')
                for meta in data_list:
                    if re.search(specified, meta):
                        meta_list = meta.split(':')
                        return meta_list[1]
            else:
                data_list = data.split(":")
                return data_list[1]

    LOG_OBJ.error("Can not get the signal information identified by %s " % (specified))
    return False


def check_service_result(message, key_value_dict={'result':0}):
    """Check API result from given message with specificed key and value

    | Input Parameters | Man. | Description |
    |     message      | Yes  | Dbus command response after invoke service API |
    | key_value_dict   | No   | dict for check item and expected value,
                                default is {'result':0} |

    Example
    | Check Service Result | ${response} |
    """
    LOG_OBJ.info('Will check expected information: %s' % (key_value_dict))
    try:
        expected_dict = {}
        if type(key_value_dict) is not dict:
            key_value = key_value_dict.replace('{', '').replace('}', '').replace('\'', '')
            for item in key_value.split(','):
                (key, value) = item.split(':')
                expected_dict[str(key)] = value
        else:
            expected_dict = key_value_dict

        LOG_OBJ.info('Will check message: %s whether matchs: %s' % (message.contents, expected_dict))
        for key in expected_dict.keys():
            if str(message.contents[0][key]) != str(expected_dict[key]):
                LOG_OBJ.error('Value: "%s" not match expected: "%s"' % (message.contents[0][key], expected_dict[key]))
    except Exception, e:
        print e
        LOG_OBJ.error('Failed to check service result')

    return True



if __name__ == "__main__":
    open_debus_switch('10.80.104.112')
    pass
