import os
import sys
import subprocess
import threading

from dbus_datatypes import DbusMessage

class DbusMonitor():
    """ Starts a dbus-monitor subprocess and registers events

        This is only valid once per Python instance, otherwise,
        the environment variables will clash
    """
    # Attributes
    _workerthread = None
    _ip = None
    _port = None
    _messagecallbacklist = None
    _continuethread = None

    def __init__(self, dbus_session_bus_ip,
                 dbus_session_bus_port='6667',
                 callbacklist=[]):
        """ Initializes the DbusMonitor and gets ready to start the thread
        """
        self._ip = dbus_session_bus_ip
        self._port = dbus_session_bus_port
        self._messagecallbacklist = callbacklist


    def RegisterCallback(self, callback):
        """ Takes a callback parameter to call it on DBUS message receipt
        """
        if not hasattr(callback, '__call__'):
            raise Exception, 'DBUS_MONITOR ERROR: RegisterCallback: Passed object \
                                   is not callable!'
        else:
            self._messagecallbacklist.append(callback)


    def UnregisterCallback(self, callback, type):
        """ Takes a callback parameter and attempts to remove it
            from the list of callbacks
        """
        if callback not in self._messagecallbacklist:
            raise Exception, 'DBUS_MONITOR ERROR: UnregisterCallback: \
                                   Object is not in callback list!'
        else:
            self._messagecallbacklist.remove(callback)


    def Start(self):
        """ Starts the thread that processes dbus-monitor
            (this will reconnect)
        """
        self._continuethread = True
        # Setup the thread
        self._workerthread = threading.Thread(target=self.RunDbusMonitor)
        self._workerthread.name = 'DbusMonitor_WorkerThread'
        self._workerthread.start()


    def Stop(self):
        """ Stops the thread that processes dbus-monitor """
        self._continuethread = False
        self._workerthread.join(5)
        del self._workerthread


    def RunDbusMonitor(self):
        """ Threaded method for running dbus-monitor with passed parameters
            and generating events on message receipt.

            Events consist of a dictionary of a DBUS message structure
            and the raw data buffer.
        """
        # Declare the buffer
        _databuffer = []

        # Generate the command and arguments
        encoding = sys.getfilesystemencoding()
        runcmd = 'dbus-monitor'

        # Change the environment variable to match the session bus IP
        dbusenv = os.environ.copy()
        sessionvar = 'tcp:host=%s,port=%s' % (self._ip, self._port)
        dbusenv['DBUS_SESSION_BUS_ADDRESS'] = sessionvar

        # Run the command
        dbusprocess = subprocess.Popen(runcmd, stdout=subprocess.PIPE,\
stderr=subprocess.STDOUT, env=dbusenv, shell=True)

        # Do a preliminatry flush for the dbusprocess's stdout
        dbusprocess.stdout.flush()
        curmsgsig = False
        while self._continuethread:
            # Get and pre-process the input (get rid of extraneous lines
            # (from bat file) and newlitnes)
            data = DbusMessage.ProcessIncomingData(dbusprocess.stdout.readline())

            # Set if the current message is a signal
            if data.startswith('signal'):
                curmsgsig = True
            elif not data.startswith('   '):
                curmsgsig = False

            # If the data completed a block of information (one method
            # call/return or signal)
            # Place a call to each of the registered callback methods
            # We can tell because there are no spaces (blocks are indented by
            # 3 spaces)
            if not data.startswith('   ') and len(_databuffer) >= 1:
                for callback in self._messagecallbacklist:
                    try:
                        event = {}
                        event['Message'] = DbusMessage.FromBufferMonitor(_databuffer)
                        event['Buffer'] = _databuffer
                        callback(event)
                    except RemoteDbusError as e:
                        print "Invalid Buffer - %s" % _databuffer
                        print e

                # Clear the buffer
                _databuffer = []

            if not data == '':
                _databuffer.append(data.rstrip().lstrip())

            # Update process data
            dbusprocess.poll()

            # If the process terminated unexpectedly
            if dbusprocess.returncode:
                self._continuethread = False
        try:
            killcmd = ['taskkill /T /F /PID %s' % dbusprocess.pid]
            killproc = subprocess.Popen(killcmd, stdout=subprocess.PIPE, shell=True)
            killproc.wait()
        except Exception as e:
            errtext = 'dbus-monitor process terminated unexpectedly!' \
                      'Error: %s' % e
            raise Exception, 'DBUS_MONITOR ERROR: %s!' % (errtext)

