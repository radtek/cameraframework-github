import json

from dbus_datatypes import DbusMessage
from dbus_monitor import DbusMonitor


class DbusJsonSnapshot():
    """ Handles the storage and recovery of data as it is seen on DBus
    """
    # The snapshot stores which services have sent and received data, and then
    snapshot = {}
    senderlist = []
    signalwaitlist = []

    def __init__(self):
        self.snapshot['methods'] = {}
        self.snapshot['signals'] = {}
        self.signal_list = []

    def ResolveDatastring(self, datastring):
        """ Parse the datastring for a list of

            Datastring must be a string in the format
            method[key1][key2][key3] etc.
        """
        try:
            snapshotkeys = datastring.replace('][', '[')
            snapshotkeys = snapshotkeys.replace(']', '')
            snapshotkeys = snapshotkeys.split('[')
        except Exception as e:
            raise Exception, 'DBUS_JSON_SNAPSHOT ERROR: Problem parsing datastring: %s' % e

        # Get a temporary dictionary and parse for each item
        tempdict = self.snapshot
        for key in snapshotkeys:
            if key in tempdict:
                tempdict = tempdict[key]
            else:
                raise Exception, 'DBUS_JSON_SNAPSHOT ERROR: Key not in snapshot data!\
                                      Tested Key: %s, Datastring: %s' % (key, datastring)

        return tempdict


    def ReceiveDbusMessage(self, message):
        # Don't parse messages that are not on the harman ServiceIpc interface
        if message.interface == 'org.freedesktop.DBus':
            return

        # Ignore invalid messages
        if not message.contents:
            return

        # Return back the signals information
        self.signal_list.append(message.contents)


    def GetUserView(self, short_service_names=True):
        if short_service_names:
            snapshotview = json.dumps(self.snapshot, sort_keys=True, indent=3)
            return snapshotview.replace('/com/harman/service/', '')
        else:
            return json.dumps(self.snapshot, sort_keys=True, indent=3)


    def Clear(self):
        self.snapshot = {}


    def SetSignalWaitList(self, signals):
        print 'DBUS_JSON_SNAPSHOT INFO: Setting SignalWaitList'
        if self.signalwaitlist:
            raise Exception, 'DBUS_JSON_SNAPSHOT ERROR: Already waiting for \
signals! These must be cleared first!'

        self.signalwaitlist = signals

        for signal in self.signalwaitlist:
            signal['Found'] = False
            signal['Data'] = None


    def GetSignalWaitList(self):
        return self.signalwaitlist


    def ClearSignalWaitList(self):
        print 'DBUS_JSON_SNAPSHOT INFO: Clearing SignalWaitList'
        del self.signalwaitlist
        self.signalwaitlist = None


