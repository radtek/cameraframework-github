"""
Used for serial control
"""
import os
import serial
from logger import Logger

LOG_OBJ = Logger('SerialConsole')
dbus_switch = '. /tmp/envars.sh'

class SerialError(Exception):
    ROBOT_CONTINUE_ON_FAILURE = True
    def __init__(self, txt):
         self.value = txt
         print "SerialConsole Error: " + self.value

    def __str__(self):
         return self.value


class SerialConsole:
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'

    def __init__(self, com_port="COM3", timeout=10, baud_rate=115200):
        self.rtn = '\r'
        self.com_port = com_port
        self.baud_rate = int(baud_rate)
        self.timeout = int(timeout)
        self.serial_conn = None
        self.is_connected = False

    def connect(self):
        """
        Create a serial connection to device through COM port, COM port number,
        baudrate and a timeout if needed.
        """
        try:
            self.serial_conn = serial.Serial(port=self.com_port, baudrate=self.baud_rate, timeout=self.timeout)
            if self.serial_conn.isOpen():
                self.is_connected = True
            else:
                LOG_OBJ.warn("Can't connect to the target")
        except Exception, e:
            print e
            LOG_OBJ.error('Failed to create serial connection')

        return self.is_connected

    def disconnect(self):
        """
        Close serial connection
        """
        self.serial_conn.close()

        if self.serial_conn.isOpen():
            LOG_OBJ.warn("Can't disconnect from the target")
            self.is_connected = True
        else:
            self.is_connected = False

        return self.is_connected

    def send_command(self, command, read_bytes=1024):
        """
        Send command and get response
        """
        try:
            self.serial_conn.write(command + self.rtn)
            try:
                ret = self.serial_conn.read(read_bytes)
                return ret
            except Exception, e:
                print e
                LOG_OBJ.error("Failed to read response after command sent")
        except serial.SerialTimeoutException:
            LOG_OBJ.error("Failed to write to the serial port")


def serial_command_send(command, com_port="COM3", timeout=10, read_bytes=1024):
    """Try to execute command through serial connection.

    | Input Parameters | Man. | Description |
    |    command       | Yes  | command need to be excuted, such as "ifconfig", "cat media_service.log" |
    |    com_port      |  No  | default is COM3 |
    |    timeout       |  No  | timeout time for serial, default is 10 seconds |
    |   read_bytes     |  No  | default is 1024 |

    Example
    | Serial Command Send | ifconfig |
    """
    LOG_OBJ.info('Execute command: %s' % (command))
    serial_obj = SerialConsole(com_port, timeout)
    try:
        serial_obj.connect()
        ret = serial_obj.send_command(dbus_switch)
        ret = serial_obj.send_command(command, read_bytes)
        LOG_OBJ.info('Command response: %s' % (ret))
    except Exception, e:
        print e
        LOG_OBJ.error("Failed to execute serial command")
    finally:
        serial_obj.disconnect()

    return ret


def get_ip_address(com_port="COM3", timeout=10, read_bytes=1024):
    """ Try to get ip address by send command "ifconfig" through serial connection.

    | Input Parameters | Man. | Description |
    |    com_port      |  No  | default is COM3 |
    |    timeout       |  No  | timeout time for serial, default is 10 seconds |
    |   read_bytes     |  No  | default is 1024 |

    | Return value | Device IP address  |

    Example
    | Get IP Address |
    """
    ret = serial_command_send('ifconfig', com_port, timeout, read_bytes)
    ret = ret.strip()
    ip_address = ret.split()[-6]

    return ip_address


if __name__ == '__main__':
    ip = get_ip_address()
    print ip
    pass
