"""

"""
import os
import time
from telnet import BaseTelnet
from device import DeviceAttributes


BASETELNET = BaseTelnet()
DEVICEATTR = DeviceAttributes()

def set_device_attributes(ip_address, port='6667'):
    """ Set device ip address and connection port.

    | Input Parameters | Man. | Description |
    |    ip_address    | Yes  | Device IP address |
    |       port       | No   | Device connect port |

    Example
    | Set Device Attributes | 10.80.104.159 | 6667 |
    """
    DEVICEATTR.set_device_attributes(ip_address, port)


def get_device_attributes():
    """ return device ip address and connection port.

    Usage Example
    | Get Device Attributes |  |

    Return Example
    | Return value | 10.80.104.159 | 6667 |
    """
    return (DEVICEATTR.ip_address, DEVICEATTR.port)


def connect_to_remote(host, user="root", passwd="", timeout="10sec", port=23):
    """This keyword opens a telnet connection to a remote host and logs in.

    | Input Parameters | Man. | Description |
    |       host       | Yes | Identifies to host |
    |       user       | No  | Authentication information. Default is 'root' |
    |      passwd      | No  | Authentication information. Default is '' |
    |      timeout     | No  | Timeout for commands issued on this connection. Default is 10 sec |
    |       port       | No  | Allows to change the default telnet port |

    | Return value | connection identifier to be used with 'Switch Host Connection' |

    Example
    | Connect To Remote | '10.80.104.199' |
    """
    return BASETELNET.connect_to_remote(host, user, passwd, timeout, port)


def execute_remote_command(command, timeout="10", password="", username="root"):
    """Execute a command on the remote system without checking the result.

    | Input Parameters  | Man. | Description |
    |     command       | Yes  | command to be executed on the remote system |
    |    password       | No   | password for user on the remote, default is "" |
    |    username       | No   | username for execute command, default is "root". |

    | Return value | command output (String) |

    Example
    | Execute Remote command | ls -la |
    """
    return BASETELNET.execute_remote_command(command, timeout, password, username)


if __name__ == '__main__':
    pass



