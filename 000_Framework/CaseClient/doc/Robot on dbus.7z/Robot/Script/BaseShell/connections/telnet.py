"""
This library supports keywords to
   - log in to a remote Linux or Microsoft Windows host via telnet
   - execute any command supported by the underlying operting system

"""
from types import MethodType
import sys
import os
import re
import time

from robot.errors import ExecutionFailed
from telnet_connection import TelnetConnection

try:
    mod = __import__("version", globals())
    __version__ = mod.version
except:
    __version__ = "0.0.0"


class BaseTelnet:
    def __init__(self):
        self._telnet_connections = {}
        self._current = None
        self._loglevel = "INFO"

    def connect_to_remote(self, host, user="root", passwd="", timeout="60sec", port=23):
        """This keyword opens a telnet connection to a remote host and logs in.

        | Input Parameters | Man. | Description |
        |      host        | Yes  | Identifies to host |
        |      user        |  No  | Authentication information. Default is 'root' |
        |     passwd       |  No  | Authentication information. Default is '' |
        |     timeout      |  No  | Timeout for commands issued on this connection. Default is 60 sec |
        |      port        |  No  | Allows to change the default telnet port |

        | Return value | connection identifier to be used with 'Switch Host Connection' |

        Example
        | Connect to Reomote | '10.80.104.199' |
        """
        prompt = ""
        myprompt = [".*#", ".*# "]

        if user != "":
            conn = TelnetConnection(host, port, myprompt, timeout, "CR")
        else:
            conn = TelnetConnection(host, port, "", timeout, "CR")

        conn.set_loglevel(self._loglevel)
        if user != "":
            ret = conn.login(user, passwd, ["login: ", "login:"], ["password: ", "Password: "])
        else:
            ret = conn.login(user, passwd, ["login:"], ["password:"])

        if ret.find("Microsoft") >= 0:
            self._telnet_connections[conn] = "Windows"
            if prompt == None or prompt == "":
                conn.set_prompt([ "^[a-zA-Z]:.*>", "^.*\(y/n\)\s*"])
        elif ret.find("[%s@" % user) >= 0: #linux
            self._telnet_connections[conn] = "Linux"
            if prompt == None or prompt == "":
                conn.set_prompt([ "%s@.*\$|\# " % user, ])
        elif ret.find("Flexi Transport Module") >= 0:
            self._telnet_connections[conn] = "Linux"
            if prompt == None or prompt == "":
                conn.set_prompt([".*#"])
        else:
            self._telnet_connections[conn] = "Device"
            if prompt == None or prompt == "":
                conn.set_prompt([ ".*>", ".*#", "Password: " ])

        self._current = conn
        return conn


    def get_current_connection_type(self):
        return self._telnet_connections[self._current]


    def set_host_prompt(self, new_prompt):
        """This keyword sets the connection prompt to new prompt other than default one.
        """
        old_prompt = self._current._prompt
        self._current.set_prompt(new_prompt)
        return old_prompt


    def disconnect_all_hosts(self):
        """Closes all existing telnet connections to remote hosts.
        """
        for conn in self._telnet_connections:
            conn.close_connection()
        self._telnet_connections = {}
        self._current = None


    def disconnect_from_remote(self):
        """Closes the telnet connections to the currently active remote host.
        """
        self._telnet_connections.pop(self._current)
        self._current.close_connection()
        if len(self._telnet_connections) == 0:
            self._current = None
        else:
            self._current = self._telnet_connections.keys()[0]


    def switch_host_connection(self, conn):
        """Switch to the connection identified by 'conn'.

        The value of the parameter 'conn' was obtained from keyword 'Connect to Host'
        """
        if conn in self._telnet_connections:
            self._current = conn
        else:
            raise RuntimeError("Unknow connection Switch Host Connection")


    def current_host_connection(self):
        """
        get current host connection.
        """
        return self._current


    def set_shell_loglevel(self, loglevel):
        """Sets the loglevel of the current host connection.

        The log level of the current connection is set. If no connection exists yet, this loglevel is used as default
        for connections created in the future. In both cases the old log level is returned, either the log level of the
        current connection or the previous default loglevel.

        | Input Paramaters | Man. | Description |
        | loglevel         | Yes  | new loglevel, e.g. "WARN", "INFO", "DEBUG", "TRACE" |

        | Return Value | Previous log level as string |
        """
        if self._current == None:
            old = self._loglevel
            self._loglevel = loglevel
            return old
        return self._current.set_loglevel(loglevel)


    def set_shell_timeout(self, timeout = "30sec"):
        """Allows to set a different timeout for long lasting commands.

        | Input Paramaters | Man. | Description |
        | timeout | No | Desired timeout. If this parameter is omitted, the timeout is reset to 30.0 seconds. |

        Example
        | Reset Timeout Test | Set MML Timeout |
        """
        return self._current.set_timeout(timeout)

    def set_pause_time(self, pause = "3"):
        """Allows to set a different timeout for long lasting commands.

        | Input Paramaters | Man. | Description |
        | timeout | No | Desired timeout. If this parameter is omitted, the timeout is reset to 30.0 seconds. |

        Example
        | Reset Pause Time Test | Set pause Timeout |
        """
        return self._current.set_pause(pause)


    def get_recv_content(self, length = 2048):
        """Allows to set a different receive length.

        | Input Paramaters | Man. | Description |
        | timeout | No | Desired timeout. If this parameter is omitted, the length is reset to 2048. |

        Example
        | get recv content | content length |
        """
        length = int(length)
        return self._current.get_recv(length)


    def execute_remote_command(self, command, timeout="10", password="", username="root"):
        """Execute a command on the remote system without checking the result.

        | Input Parameters  | Man. | Description |
        | command           | Yes  | command to be executed on the remote system |
        | timeout           | No   |  sleep time if need to set command timeout |
        | password          | No   | password for user on the remote system (Linux only) |
        |                   |      | default is "", execute command as current user. |
        | username          | No   | username for execute command on the remote system (Linux only) |
        |                   |      | default is "root". |

        | Return value | command output (String) |

        Example
        | Execute Remote Command | ${command} |                  | # execute command as current user. |
        | Execute Remote Command | ${command} | ${root password} | # execute command as root. |
        """
        if self._telnet_connections[self._current] == "Linux" and password != "":
            self._current.write("su " + username)
            origprompt = self._current.set_prompt("Password:")
            self._current.read_until_prompt(None)
            self._current.write(password)
            origprompt.append("%s@.*[\$|\#] " % username)
            self._current.set_prompt(origprompt)
            self._current.read_until_prompt()
            self._current.write('echo $?')
            return_lines = self._current.read_until_prompt().splitlines()
            try:
                return_code = int(return_lines[0])
            except ValueError:
                return_code = int(return_lines[1])
            if return_code != 0:
                raise ExecutionFailed, 'CANNOT to change user %s with password:%s.' % (username, password)

        self._current.write(command)
        try:
            return self._current.read_until_prompt()
        except AssertionError, e:
            print e
            time.sleep(float(timeout))
            self._current.write('\x13')

        self._current.write('\x03')
        raise Exception, "command '%s' execution failed:'%s'" %(command, e)


if __name__ == '__main__':
    tl = BaseTelnet()
    tl.connect_to_remote('10.80.104.199','root', '')
    tl.execute_remote_command('ls -la')
    tl.disconnect_from_remote()
    pass
