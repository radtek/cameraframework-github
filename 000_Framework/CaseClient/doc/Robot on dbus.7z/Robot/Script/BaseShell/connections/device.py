"""
Stores device attributes
"""

class DeviceAttributes:
    def __init__(self):
        self.ip_address = ''
        self.port = ''

    def set_device_attributes(self, ip_address, port='6667'):
        self.ip_address = ip_address
        self.port = port


if __name__ == '__main__':
    pass

